# niceTron-CUDA
  Nicetron CUDA版本相较于OpenCL版本（就是传统的GPU版本）具备优异的的算力速度，为您节约算力成本，前后缀模式算法加速优化后是GPU版本的4倍左右，靓号模式是GPU的2倍左右。
考虑到波场Tron TRX地址是私密的，本CUDA版本设计延续GPU版本的离线设计方案，授权原理是绑定CPU ID号，CUDA版本软件自身不需要任何网络，最大程度保障用户的私钥的安全。

  全网最快！波场靓号|| 靓号生成器&离线版本& Trton TRX 靓号 生成工具|| 支持后缀靓号生成||支持自定义后最||最快的靓号生成工具||专业开发靓号GPU加速软件||修改软件联系 [@serokf](https://t.me/serokf)
1. 2023-04-18 已支持笔记本电脑独立显卡运行，适配过的显卡有RTX5090、RTX4090、RTX4070、RTX3090、RTX2080\2060、RTX1660\1650、A100\V100\T4
2. 2023-04-21 已支持亚马逊云、阿里云、腾讯云GPU主机，支持 windowsserver2022 数据中心（DCH）操作系统，需自行安装英伟达驱动。支持多GPU卡，程序已适配显卡型号：V100、A100
3. 2025-06-15 更新v2.48版本，所有显卡计算提升25%，修复部分异常故障。
4. 关注频道了解最新更新动态 [@TronLiangHaoZX](https://t.me/TronLiangHaoZX)
**计算时间说明**
RTX 2060s|| 3-5  25分钟||3-6  24.2小时||3-7  58.5天||3-8 9.3年
RTX 4090||3-5  4.5分钟||3-6  4.3小时||3-7  10.5天||3-8 1.7年
RTX 4090 8卡||3-5  34秒||3-6  32分钟||3-7  32.1小时||3-8 2.6月
RTX 5090速度比RTX 4090快20%
**使用说明**

1)第一步安装英伟达官网CUDA驱动
驱动下载地址https://developer.nvidia.com/cuda-downloads?target_os=Windows&target_arch=x86_64&target_version=11&target_type=exe_local
<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%871.png" width="600px">

2)点击“运行-前后缀模式-单卡.bat”


<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%876.png" width="600px">
<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%877.png" width="600px">

3)点击“运行-靓号模式-单卡.bat”

<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%872.png" width="600px">
<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%873.png" width="600px">
<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%874.png" width="600px">
<img src="https://github.com/hxb0614/niceTron-CUDA/blob/main/%E5%9B%BE%E7%89%87/%E5%9B%BE%E7%89%875.png" width="600px">

**本软件计算的靓号样板**
TFexvpkbvr4wFPAGDg7cthqY4888888888
TJjCBan3aCGhSnYtdGdPkfmPg111111111
TXAy3ZmB2uUwiDcydhqEJc8tX444444444
TLVtztS5hwppXxGsboG3AVPy4666666666
TRSd9Rc7wCAA2phSNyCJ3crBC444444444
TBRFdfeRrDE84fQwjfnveSvL3777777777
THhF71gvCjSUQ7VGHQwWG1VCy333333333
TQTyCbkusQ4gw9A8upPircVgo444444444
TWZunfVCXLfTWo4hbiLU9x5CY999999999

英伟达CUDA版最快的波场靓号生成 &amp; 波场地址生成 &amp; tron靓号生成 &amp; tron地址生成 &amp; 地址离线生成 &amp; 靓号离线生成&amp;TRX靓号生成&amp;支持自定义尾号&amp;GPU加速
nicetron-前后缀&靓号cuda版-v2.30使用说明


